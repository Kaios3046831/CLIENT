The code in this directory contains code based on Adrian Machado's KaiUI and
made to work with InfernoJS.
